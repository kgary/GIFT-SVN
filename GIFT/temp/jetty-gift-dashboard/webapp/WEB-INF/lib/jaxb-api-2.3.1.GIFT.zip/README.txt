This folder contains the Maven project used to build the jaxb-api-2.3.1.GIFT.jar JAR, which is a modified version of jaxb-api-2.3.1.jar designed to work with GIFT. 

It is a copy of the jaxb-api folder of the javaee/jaxbspec project version 2.3.1 that has been modified in order to fix several classloading issues related to JAXB's ContextFinder class.

The classloading issues described were captured in a defect ticket (see https://github.com/eclipse-ee4j/jaxb-api/issues/121) and pushed into JAXB 3.0.1, but they affect earlier versions of JAXB as well, particularly the 2.3.1 JAR that GIFT uses. This ends up causing problems within GIFT contexts that use multiple classloaders, such as servers and the single processlauncher, so in order to fix these classloading issues, the JAXB 2.3.1 JAR had to be modified to include the fix that was made as a result of the defect ticket, which can be found here: https://github.com/lukasj/jaxb-api/commit/433f894c5eff6fe074d6fa8cdee29acbfc3fe4aa?diff=unified.

For more information about the issues that resulted in the creation of this JAR, visit https://gifttutoring.org/issues/5252.

Should jaxb-api-2.3.1.GIFT.jar need to be rebuilt, the Maven project can be used to perform the rebuild. This can be done by doing the following:
1. Import the jaxb-api folder to Eclipse as an existing Maven project
2. Perform whatever source code changes are needed (if any)
3. Right click the project in Eclipse and click "Run As > Maven install"
4. Navigate to the jaxb-api/target folder to find the newly built JAR
5. Rename the JAR to jaxb-api-2.3.1.GIFT.jar.